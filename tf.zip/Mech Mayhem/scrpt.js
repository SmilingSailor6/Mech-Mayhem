const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
let score = 0;

// Sample mech
const mech = { x: 375, y: 500, width: 50, height: 50 };

function update() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw mech
    ctx.fillStyle = 'blue';
    ctx.fillRect(mech.x, mech.y, mech.width, mech.height);

    // Update score
    document.getElementById('score').innerText = score;

    requestAnimationFrame(update);
}

// Start the game
update();
